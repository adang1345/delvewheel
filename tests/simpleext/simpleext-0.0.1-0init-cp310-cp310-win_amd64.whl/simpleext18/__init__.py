"doc\
string"
