#!/usr/bin/env python
# comment
# comment

# comment

def dummy():
    pass
