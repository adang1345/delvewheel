"docstring"

def dummy():
    """dummy"""
    pass
