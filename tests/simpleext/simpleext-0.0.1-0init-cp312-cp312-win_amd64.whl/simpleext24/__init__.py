"""Unix-style line endings"""
