# coding=windows-1252
"""Windows-1252 encoding �"""

� = 1
