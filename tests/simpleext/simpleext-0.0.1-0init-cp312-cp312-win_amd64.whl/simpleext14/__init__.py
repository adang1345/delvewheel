#!/usr/bin/env python
# comment
# comment

def dummy():
    pass
