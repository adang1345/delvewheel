# coding=windows-1252
# delvewheel:  patch

import os

� = 1
