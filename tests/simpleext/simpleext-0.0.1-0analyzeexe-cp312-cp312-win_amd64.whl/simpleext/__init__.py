import os
import subprocess

dll_path = os.path.normpath(os.path.join(os.path.dirname(__file__), os.pardir, 'simpleext.libs'))
exe_path = os.path.normpath(os.path.join(os.path.dirname(__file__), 'simpleexe.exe')) 
os.environ['PATH'] += ';' + dll_path

subprocess.run(exe_path, check=True)
